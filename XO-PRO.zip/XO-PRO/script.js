// عناصر الصفحة
const board = document.getElementById("board");
const statusText = document.getElementById("status");
const menu = document.getElementById("menu");
const game = document.getElementById("game");
const scoreXText = document.getElementById("scoreX");
const scoreOText = document.getElementById("scoreO");

// متغيرات اللعبة
let cells, currentPlayer, gameOver, mode;
let scoreX = 0, scoreO = 0;

// الحالات الفائزة
const wins = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6]
];

// بداية اللعبة بعد اختيار الوضع
function startGame(selectedMode) {
  mode = selectedMode;
  menu.classList.add("hidden");
  game.classList.remove("hidden");
  resetRound();
}

// العودة للقائمة
function backToMenu() {
  game.classList.add("hidden");
  menu.classList.remove("hidden");
}

// إعادة جولة جديدة
function resetRound() {
  board.innerHTML = "";
  cells = Array(9).fill("");
  currentPlayer = "X";
  gameOver = false;
  statusText.textContent = "دور اللاعب: X";

  for (let i = 0; i < 9; i++) {
    const c = document.createElement("div");
    c.className = "cell";
    c.onclick = () => play(i, c);
    board.appendChild(c);
  }
}

// تنفيذ حركة اللاعب
function play(i, cell) {
  if (cells[i] || gameOver) return;

  makeMove(i, currentPlayer, cell);

  if (checkWin(currentPlayer)) return endGame(currentPlayer);
  if (isDraw()) return drawGame();

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusText.textContent = `دور اللاعب: ${currentPlayer}`;

  if (mode === "ai" && currentPlayer === "O") {
    setTimeout(aiMove, 400);
  }
}

// حركة الذكاء الاصطناعي (Minimax)
function aiMove() {
  let best = minimax(cells, "O").index;
  makeMove(best, "O", board.children[best]);

  if (checkWin("O")) return endGame("O");
  if (isDraw()) return drawGame();

  currentPlayer = "X";
  statusText.textContent = "دور اللاعب: X";
}

// تنفيذ الحركة على الشاشة
function makeMove(i, p, cell) {
  cells[i] = p;
  cell.textContent = p;
  cell.classList.add(p.toLowerCase());
}

// التحقق من الفوز
function checkWin(p) {
  return wins.some(w => w.every(i => cells[i] === p));
}

// التحقق من التعادل
function isDraw() {
  return !cells.includes("");
}

// إنهاء اللعبة عند الفوز
function endGame(winner) {
  gameOver = true;
  if (winner === "X") scoreX++; else scoreO++;
  updateScore();
  statusText.textContent = `🎉 ${winner} فاز`;
}

// إنهاء اللعبة عند التعادل
function drawGame() {
  gameOver = true;
  statusText.textContent = "😐 تعادل";
}

// تحديث النقاط على الشاشة
function updateScore() {
  scoreXText.textContent = `X : ${scoreX}`;
  scoreOText.textContent = `O : ${scoreO}`;
}

// ذكاء اصطناعي Minimax
function minimax(newBoard, player) {
  const avail = newBoard.map((v,i)=>v===""?i:null).filter(v=>v!==null);

  if (checkStatic(newBoard,"X")) return {score:-10};
  if (checkStatic(newBoard,"O")) return {score:10};
  if (avail.length === 0) return {score:0};

  let moves = [];

  for (let i of avail) {
    let move = {index:i};
    newBoard[i] = player;

    let result = minimax(newBoard, player==="O"?"X":"O");
    move.score = result.score;

    newBoard[i] = "";
    moves.push(move);
  }

  let bestMove;
  if (player === "O") {
    let bestScore = -Infinity;
    for (let m of moves)
      if (m.score > bestScore) bestScore = m.score, bestMove = m;
  } else {
    let bestScore = Infinity;
    for (let m of moves)
      if (m.score < bestScore) bestScore = m.score, bestMove = m;
  }

  return bestMove;
}

function checkStatic(b,p) {
  return wins.some(w => w.every(i => b[i] === p));
}ore, bestMove = m;
  }

  return bestMove;
}

// التحقق للفحص داخل Minimax
function checkStatic(b,p) {
  return wins.some(w => w.every(i => b[i] === p));
}